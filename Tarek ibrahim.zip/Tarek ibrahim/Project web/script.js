var counter = 1;
setInterval(function () {
    document.getElementById('radio' + counter).checked = true;
    counter++;
    if (counter > 2) {
        counter = 1;
    }
}, 5000);
function validateForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("psw").value;
    var repeat_password = document.getElementById("psw-repeat").value;

    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return false;
    }
    if ( repeat_password != password) {
        alert("You inputed the wrong password.");
        return false;
    }
    return true;
}

function goBack() {
    window.location.href = "home.html";
}